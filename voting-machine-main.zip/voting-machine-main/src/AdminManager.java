public class AdminManager {

    private Latch latch;
    private
    public AdminManager(){

    }
}
