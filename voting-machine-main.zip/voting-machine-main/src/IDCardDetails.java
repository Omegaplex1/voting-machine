public record IDCardDetails(int cardNumber, char cardType) {


}
