public class Selection {
    public String name;
    public boolean selected;
    public Selection(String name){
        this.name;
        this.selected=false;
    }
}
