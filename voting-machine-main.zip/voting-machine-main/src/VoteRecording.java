public class VoteRecording {
}
