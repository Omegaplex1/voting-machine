public class VotingManager {
}
